$(document).ready(function () {
    var date = new Date();
    $('#year').text(date.getFullYear());
});