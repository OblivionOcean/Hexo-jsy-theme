var date = new Date();
$('#year').text(date.getFullYear());